'use strict';

const init = () => {
    require('dotenv').config();
};

module.exports = init;