# Login URL
https://note4g.auth.us-east-1.amazoncognito.com/login?response_type=token&client_id=6r9jdgobm0qkkvc7rtjb1hk362&redirect_uri=http://localhost:3000

